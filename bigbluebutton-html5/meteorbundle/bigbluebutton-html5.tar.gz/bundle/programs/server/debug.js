
exports.pause = function () {
  // The debugger pauses here when you run `meteor debug`, so that you can
  // set breakpoints or add `debugger` statements to your server code
  // before the code begins executing. Once you have set any breakpoints
  // you wish to set, click the |▶ button to continue.
  debugger;
};